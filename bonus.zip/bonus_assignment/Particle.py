class Particle:
    def __init__ (self):
        # should randomize position x from 0 to width
        self.pos_x = random (0, width)
        # position y from 0 to height
        self.pos_y = random (0, height)
        # velocity x from -5 to 5
        self. velocity_x = random (-5, 5)
        # velocity y from -5 to 5
        self.velocity_y = random (-5, 5)
        self.sz = 15
       

    def move(self):
        # Should move the particle according to its velocity.
        self.pos_x = self.pos_x + self.velocity_x
        self.pos_y = self.pos_y + self.velocity_y
        if self.pos_x > width - self.sz:
            self.velocity_x *= -1
        if self.pos_x < 0 :
            self.velocity_x *= -1
        if self.pos_y > height - self.sz:
            self.velocity_y *= -1
        if self.pos_y < 0:
            self.velocity_y *= -1
       
  
    def draw_it(self):
        # Should draw a circle where the particle is.
        circle(self.pos_x, self.pos_y, self.sz)
        
